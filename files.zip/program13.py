# Date: 18/11/2025
# Program Number: 13
# Program: List operations: create, append, extend, remove.
fruits = []
fruits.append("Apple")
fruits.append("Banana")
fruits.extend(["Mango", "Orange", "Grapes"])
print("Fruits List after append and extend:", fruits)
fruits.remove("Orange")
print("Fruits List after remove:", fruits)