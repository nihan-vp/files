# Date: 29/10/2025
# Program Number: 05
# Program: To count from 10 to 1 using while loop.
number = 10
while number >= 1:
    print(number)
    number -= 1