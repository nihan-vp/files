# Date: 4/11/2025
# Program Number: 08
# Program: To convert Celsius to Fahrenheit. (F = C*9/5 + 32)
c = int(input("Enter the temperature in Celsius: "))
f = c * 9 / 5 + 32
print("The temperature in Fahrenheit is", f)