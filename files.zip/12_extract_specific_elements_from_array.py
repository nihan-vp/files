# Date: 11/11/2025
# Program Number: 12
# Program: To extract specific elements from an array.
my_list = [10, 20, 30, 40, 50]
element_at_index_0 = my_list[0]
print("Element at index 0:", element_at_index_0)