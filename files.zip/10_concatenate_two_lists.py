# Date: 5/11/2025
# Program Number: 10
# Program: To concatenate two lists.
list1 = [1, 2, 3]
list2 = ["a", "b", "c"]
concatenated_list = list1 + list2
print(concatenated_list)