# Date: 4/11/2025
# Program Number: 07
# Program: To swap two variables.
x = int(input("Enter value of x: "))
y = int(input("Enter value of y: "))
temp = x
x = y
y = temp
print("The value of x after swapping:", x)
print("The value of y after swapping:", y)