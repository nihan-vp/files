# Date: 28/10/2025
# Program Number: 02
# Program: To calculate the area and perimeter of a rectangle.
L = int(input("Enter the length of the rectangle: "))
B = int(input("Enter the breadth of the rectangle: "))
P = 2 * (L + B)
A = L * B
print("The perimeter of the rectangle is", P)
print("The area of the rectangle is", A)