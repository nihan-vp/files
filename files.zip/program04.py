# Date: 29/10/2025
# Program Number: 04
# Program: To check whether a number is even or odd.
num = int(input("Enter a number: "))
if num % 2 == 0:
    print("Number is even")
else:
    print("Number is odd")