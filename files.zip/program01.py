# Date: 28/10/2025
# Program Number: 01
# Program: To find the Sum and Product of two numbers.
num1 = 38
num2 = 45
sum = num1 + num2
product = num1 * num2
print("Sum of 38 & 45 is", sum)
print("Product of 38 & 45 is", product)