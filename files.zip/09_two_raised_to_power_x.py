# Date: 5/11/2025
# Program Number: 09
# Program: To find out 2 raised to power x, where x is taken as input.
x = int(input("Enter any number: "))
result = 2 ** x
print(result)