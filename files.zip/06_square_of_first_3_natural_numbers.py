# Date: 29/10/2025
# Program Number: 06
# Program: To display the square of first 3 natural numbers.
for x in range(1, 4):
    x = x * x
    print(x)