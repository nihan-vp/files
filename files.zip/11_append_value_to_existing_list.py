# Date: 11/11/2025
# Program Number: 11
# Program: To append a value to an existing list.
my_list = [10, 20, 30]
print("Original list:", my_list)
new_value = 40
my_list.append(new_value)
print("List after appending new value is", my_list)