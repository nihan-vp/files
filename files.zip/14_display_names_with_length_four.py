# Date: 18/11/2025
# Program Number: 14
# Program: Display all names with length four.
names = ["John", "Mike", "Sara", "Anna", "Chris", "Ella", "Tom"]
for n in names:
    if len(n) == 4:
        print(n)